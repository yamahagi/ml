p(a).
q(b).
