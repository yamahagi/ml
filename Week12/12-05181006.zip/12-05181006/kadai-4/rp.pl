r(a) :- p(a).
r(a) :- \+p(a).
p(a).
p(X) :- p(f(X)).
